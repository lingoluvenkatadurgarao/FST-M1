package Activities.Activity4_suiteExample;

import org.testng.annotations.Test;

public class DemoOne {
    @Test
    public void test_TestCase1(){
        System.out.println("I'm first test case from DemoOne");
    }

    @Test
    public void test_TestCase2(){
        System.out.println("I'm  second test case from DemoTwo");
    }
}
